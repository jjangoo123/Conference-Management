﻿using Microsoft.EntityFrameworkCore;
using ConferenceManagement.Models;
namespace ConferenceManagement.Data
{
    public class ConferenceContext :DbContext
    {
        public ConferenceContext(DbContextOptions<ConferenceContext> options)
            : base(options)
        {
        }

        public DbSet<Conference> Conference { get; set; }
    }
}
