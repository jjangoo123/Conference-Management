﻿using System;
using System.ComponentModel.DataAnnotations;


namespace ConferenceManagement.Models
{
    public class User
    {
       protected EmailAddressAttribute Email { get; set; }
        protected PhoneAttribute Phone { get; set; }


    }
}

