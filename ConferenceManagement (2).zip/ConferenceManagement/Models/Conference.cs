﻿using System;
using System.ComponentModel.DataAnnotations;


namespace ConferenceManagement.Models
{
    public class Conference
    {
        public int ConferenceId { get; set; }
        public string ConferenceName { get; set; }

        [DataType(DataType.Date)]
        public DateTime Date { get; set; }
        public string Location { get; set; }
        
    }
}
