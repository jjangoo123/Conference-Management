﻿using System;
using System.ComponentModel.DataAnnotations;


namespace ConferenceManagement.Models
{
    public class Organiser : User
    {
        public int OrganiserId { get; set; }
        public string OrganiserName { get; set; }

        public void OrganiserEmail(EmailAddressAttribute Email)
        {
            
            Email = new EmailAddressAttribute();
        }
        public void OrganiserPhone(PhoneAttribute Phone)
        {
            Phone = new PhoneAttribute();
        }
    }
}
